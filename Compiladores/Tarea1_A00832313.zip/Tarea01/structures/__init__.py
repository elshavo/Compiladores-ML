# Permite importar desde structures.* de forma ordenada

from .stack import Stack
from .queue import Queue
from .hashtable import HashTable
